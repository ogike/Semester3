# Ticket-to-ride

- [x] a.
- [x] b.
- [x] c.
- [x] d.
- [x] e.
- [x] f.
