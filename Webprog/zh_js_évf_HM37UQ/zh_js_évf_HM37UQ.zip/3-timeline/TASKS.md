# 3. Timeline

- [x] a.
- [x] b.
- [x] c.
- [x] d.
- [x] e.
- [x] f.
- [ ] g.
