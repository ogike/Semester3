# 2. Image filters

- [x] a.
- [x] b.
- [x] c.
- [x] d.
- [ ] e.
