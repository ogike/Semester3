# Task 3

- [x] a.
- [x] b.
- [x] c.
- [x] d.
- [x] e.
- [x] f.
- [x] g.
