package bead_1_hm37uq;

/**
 * The exception to be thrown when there trying to find the maximum of an empty collection.
 * @author ogike
 */
public class EmptyCollectionException extends Exception {
    public EmptyCollectionException() {}
}