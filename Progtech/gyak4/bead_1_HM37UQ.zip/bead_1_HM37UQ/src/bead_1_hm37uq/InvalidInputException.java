package bead_1_hm37uq;

/**
 * The exception to be thrown when there is either an invalid input.
 * @author ogike
 */
public class InvalidInputException extends Exception {
    public InvalidInputException() {}
}
