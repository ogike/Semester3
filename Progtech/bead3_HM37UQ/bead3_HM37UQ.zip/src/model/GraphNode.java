/*

 */
package model;

/**
 *
 * @author ogike
 */
public class GraphNode {
}
