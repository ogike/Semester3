package bead2_hm37uq;
//Idk if this is where the entry point should be

import view.MainWindow;

/**
 *
 * @author ogike
 */
public class Bead2_HM37UQ {

    public static void main(String[] args) {
        MainWindow mainWindow = new MainWindow();
        mainWindow.setVisible(true);
    }

    
}
